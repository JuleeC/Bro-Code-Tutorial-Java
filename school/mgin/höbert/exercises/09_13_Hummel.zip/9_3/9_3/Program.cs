﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            parent p = new parent();
            c1 c = new c1();
            c2 cc= new c2();
            c3 ccc = new c3();
            p.Schlafen();
            c.Schlafen();
            cc.Schlafen();
            ccc.Schlafen();
        }


        class parent {
            public int alter;
            public bool geschlecht;
           

            public void Schlafen()
            {
                Console.WriteLine("Person schläft");
            }
        }
        class c1 :parent{
        
        }
        class c2 :parent{
            public new void Schlafen() { Console.WriteLine("Mann schläft / Frau schläft"); }
        }
        class c3 :parent{
            public new void Schlafen()
            {
                base.Schlafen();
                Console.Write("und isst ein Sandwich");
            }
        }


    }
}
