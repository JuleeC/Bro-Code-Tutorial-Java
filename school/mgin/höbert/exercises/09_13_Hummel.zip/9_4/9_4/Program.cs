﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
    class Fahrzeug
    {
        public int Fahrzeugnummer;
        public int Leergewicht;
        public bool Verfuegbarkeit;

        public void GetData()
        {
            Console.WriteLine(Fahrzeugnummer + " " + Leergewicht + " " + Verfuegbarkeit);
        }
    }

    class Kraftfahrzeug : Fahrzeug {
        public int Hoechstgeschwindigkeit;
        public int Leistung;
        public int zulaessigesGesamtgewicht;

        public void PreuefeFahrererlaubnis(string kat)
        {
            if(kat == "B")
            {
                Console.WriteLine("Fahrer darf Auto fahren");
            } else if(kat == "A")
            {
                Console.WriteLine("Fahrer darf Auto fahren");
            }
        }
        public void GetSound() {
            Console.WriteLine("wremm wremm");
        }

        public  new void GetData()
        {
            base.GetData();
            Console.WriteLine(Hoechstgeschwindigkeit + " " + Leistung + " " + zulaessigesGesamtgewicht);
        }
    }
    class Fahrrad : Fahrzeug {
        public byte Rahmenhoehe;
        public byte AnzahlGaenge;

        public new void GetData()
        {
            base.GetData();
            Console.WriteLine(Rahmenhoehe + " " + AnzahlGaenge);
        }

    }

    class Motorrad : Kraftfahrzeug
    {
        public new void PreuefeFahrererlaubnis(string kat)
        {
            if (kat != "A") { Console.WriteLine("Fahrer darf ncht fahren"); }
        }
        public new void GetSound()
        {
            Console.WriteLine("miii");
        }
        public new void GetData() { base.GetData(); }
    }

    class PKW : Kraftfahrzeug {
        public byte AnzahlSitzplaetze;

        public new void PreuefeFahrererlaubnis(string kat)
        {
            if (kat != "B") { Console.WriteLine("Fahrer darf ncht fahren"); }
        }
        public new void GetData() { base.GetData(); Console.WriteLine(AnzahlSitzplaetze); }
    }
}
