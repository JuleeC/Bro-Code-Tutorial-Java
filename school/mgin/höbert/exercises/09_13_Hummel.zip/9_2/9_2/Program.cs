﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Benutzer b = new Benutzer();
            b.Benutzername = "Herbert";
            Adminstrator a = new Adminstrator();
            Hauptbenutzer h = new Hauptbenutzer();
            Standardbenutzer s = new Standardbenutzer();

            a.Zugriffsrechte();
            h.Zugriffsrechte();
            s.Zugriffsrechte();
        }
    }

    class Benutzer
    {
        public String Benutzername;

        public void Zugriffsrechte()
        {
            Console.WriteLine(Benutzername +  "hat Zugriff auf Laufwerk C:");
        }
    }
    class Adminstrator : Benutzer
    {
        public new void Zugriffsrechte() { Console.WriteLine("Adminstrator hat Vollzugriff")}
    }
    class Hauptbenutzer : Benutzer
    {
        public new void Zugriffsrechte() { 
            base.Zugriffsrechte();
            Console.Write("und Benutzer hat Zugriff auf Laufwerk D:");
        }
    }
    class Standardbenutzer : Benutzer
    {

    }
}
