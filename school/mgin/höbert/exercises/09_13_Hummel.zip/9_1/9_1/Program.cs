﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hund h = new Hund();
            Katze k = new Katze();
            h.GetBeine();
            k.GetBeine();
            h.GetLaut();
            k.GetLaut();
        }
    }


    class Tier {
        public String Name;
        public int Beine;

        public void GetBeine()
        {
            Console.WriteLine("4");
        }
    }
    class Hund : Tier {
        public void GetLaut()
        {
            Console.WriteLine("wau wau");
        }
    }
    class Katze : Tier {
        public void GetLaut()
        {
            Console.WriteLine("miauu");
        }
    }
}
