﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace übung1
{
    internal class Schueler
    {
        public int Katalognummer;
        public string Vorname;
        public string Nachname;
        public int Betrag;


       
    }
}
