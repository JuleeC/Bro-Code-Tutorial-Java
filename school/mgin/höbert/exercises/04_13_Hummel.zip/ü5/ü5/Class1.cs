﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ü5
{
    internal class Konto
    {
        private string Name;
        private int Kontostand;
        private string Passwort;

        public string MyName
        {
            get { return Name; }
            set { Name = value; }
        }

        public int MyKontostand
        {
            get { return Kontostand; }
            set {
                if (Kontostand < 0)
                {
                    Console.WriteLine("Kontostand darf nicht ins Negative");
                }
                else if (value >= 1000)
                {
                    Console.WriteLine("max 1000 euro");
                }
                else
                {
                    Kontostand += value;
                    Console.WriteLine("------------");
                }
                
            }
        }

        public string MyPasswort
        {
            set { Passwort = value; }
        }

    }
}
