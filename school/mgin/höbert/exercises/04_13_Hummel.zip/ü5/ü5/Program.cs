﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ü5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Konto konto = new Konto();
            bool x = true;
            Console.WriteLine("Mit Null beenden");
            while (x)
            {
                
                
                if ("0" == Console.ReadLine())
                {
                    x =  false;
                    
                } else
                    konto.MyKontostand = Convert.ToInt32(Console.ReadLine());
            }
            

            
        }
    }
}
