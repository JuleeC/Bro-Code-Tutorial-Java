﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace übung4
{
    internal class Referenzklasse
    {
      

        private int RefernzwertA;

        public int schreibschutz
        {
           
            set { RefernzwertA= value; }
        }

        private int RefernzwertB;

        public int leseschutz
        {
            get { return RefernzwertB; }
           
        }


    }
}
