﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace übung3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            Quader quader= new Quader();
            quader.MyHoehe = -5000;
            quader.MyLaenge = -500;
            quader.MyBreite = -500;
            Console.WriteLine(quader.MyLaenge);
            Console.WriteLine(quader.MyBreite);
            Console.WriteLine(quader.MyHoehe);


        }
    }
}
