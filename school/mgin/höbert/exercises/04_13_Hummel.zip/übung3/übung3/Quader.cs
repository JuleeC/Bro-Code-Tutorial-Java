﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace übung3
{
    internal class Quader
    {
        private int Laenge;
        private int Breite;
        private int Hoehe;

        

        public int MyLaenge
        {
            get { return Laenge; }
            set {
                if (value >= 0 && value < 1000)
                {
                    Laenge = value;
                }
            }
               
        }

        public int MyBreite
        {
            get { return Breite; }
            set
            {
                if (value >= 0 && value < 1000)
                {
                    Breite = value;
                }
            }

        }

        public int MyHoehe
        {
            get { return Hoehe; }
            set
            {
                if (value >= 0 && value < 1000)
                {
                    Hoehe = value;
                    
                }
            }

        }


    }
}
