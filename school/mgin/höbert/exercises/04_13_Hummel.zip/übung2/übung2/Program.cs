﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace übung2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Test test = new Test();
            Console.WriteLine(test.int_var);
            Console.WriteLine(test.double_var);
            Console.WriteLine(test.bool_var);
            Console.WriteLine(test.string_var);
            Console.WriteLine(test.char_var);
            Console.WriteLine(test.object_var);
 

        }
    }

    class Test
    {
        public int int_var;
        public double double_var;
        public bool bool_var;
        public char char_var;
        public string string_var;
        public object object_var;

    }
}
