﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Schueler s = new Schueler("florian","gössl");
            
        }
    }

    class Schueler
    {
        public string Nachname;
        public string Vorname;
        public int Knr;
        public string Klasse;
        public bool Geschlecht;
        public DateTime Geburtsdatum;

        
        public Schueler()
        {

        }
        public Schueler(string nachname) : this(nachname, null, 0, null, false, null)
        {
        }

        public Schueler(string nachname, string vorname) : this(nachname, vorname, 0, null, false, null)
        {
        }

        public Schueler(string nachname, string vorname, int knr) : this(nachname, vorname, knr, null, false, null)
        {

        }

        public Schueler(string nachname, string vorname, int knr, string klasse) : this(nachname, vorname, knr, klasse, false, null)
        {

        }

        public Schueler(string nachname, string vorname, int knr, string klasse, bool geschlecht) : this(nachname, vorname, knr, klasse, geschlecht, null)
        {
        }

        public Schueler(string nachname, string vorname, int knr, string klasse, bool geschlecht, string geburtsdatum)

        {
            this.Nachname = nachname;
            this.Vorname = vorname;
            this.Knr = knr;
            this.Klasse = klasse;
            this.Geschlecht = geschlecht;
            this.Geburtsdatum = Convert.ToDateTime(geburtsdatum);
        }
    }
}
