﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Zylinder z = new Zylinder(5);
            Zylinder z1 = new Zylinder(5,3);
            Zylinder z2 = new Zylinder(5,6,3);
            Zylinder z3 = new Zylinder(5,7,7,7);

            z3.PrintData();
        }
    }

    class Zylinder
    {
        private int Radius;
        private int Hoehe;
        private int XKoordinate;
        private int Yoordinate;

        public Zylinder() { }

        public Zylinder(int Radius)
        {
            this.Radius = Radius;
        }
        public Zylinder(int Radius, int Hoehe) : this(Radius)
        {
            this.Hoehe = Hoehe;
        }
        public Zylinder(int Radius, int Hoehe,int XKoordinate) : this(Radius, Hoehe)
        {
            this.XKoordinate = XKoordinate;
        }
        public Zylinder(int Radius,int Hoehe, int XKoordinate, int YKoordinate) :this(Radius,Hoehe,XKoordinate)
        {
            this.Yoordinate = YKoordinate;
        }

        public void PrintData()
        {
            Console.WriteLine(Radius + "  " + Hoehe + "  " + XKoordinate + " "+ Yoordinate);
        }
    }
}

