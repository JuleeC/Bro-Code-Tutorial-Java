﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rechteck r  =new Rechteck(10,20,"Grün");
            Kreis k = new Kreis(10, 1, "Blau");
            Trapez t = new Trapez(5, 2, "Rot");
            r.print();
            k.print();
            t.print();
            
        }
    }
    class Rechteck
    {
        private int Länge;
        private int Breite;
        private String Farbe;

        public Rechteck(int Länge,int Breite, String Farbe)
        {
            this.Länge = Länge;
            this.Breite = Breite;
            this.Farbe = Farbe;
        }

        public void print()
        {
            Console.WriteLine(Länge + "  " + Breite + "  " + Farbe);
        }
    }


    class Kreis {
        private int Länge;
        private int Breite;
        private String Farbe;

        public Kreis(int Länge, int Breite, String Farbe)
        {
            this.Länge = Länge;
            this.Breite = Breite;
            this.Farbe = Farbe;
        }
        public void print()
        {
            Console.WriteLine(Länge + "  " + Breite + "  " + Farbe);
        }
    }

    class Trapez
    {
        private int Länge;
        private int Breite;
        private String Farbe;

        public Trapez(int Länge, int Breite, String Farbe)
        {
            this.Länge = Länge;
            this.Breite = Breite;
            this.Farbe = Farbe;
        }
        public void print()
        {
            Console.WriteLine(Länge + "  " + Breite + "  " + Farbe);
        }
    }
}

