﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person("Hummel", "Jules", "21.01.1944");
            p.PrintData();
        }
    }

    class Person
    {
        public String FirstName;
        public String LastName;
        public DateTimeOffset Birthday;
        
        public Person() { }

        public Person(String FirstName, String LastName)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
        }

        public Person(String FirstName, String LastName, String Birthday) :this(FirstName, LastName)
        {
          
            this.Birthday = Convert.ToDateTime(Birthday);
        }

        public void PrintData()
        {
            Console.WriteLine(FirstName + "  " + LastName + "  " + Birthday);
        }
    }
}
