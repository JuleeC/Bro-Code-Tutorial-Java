﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {1,2,3};

            Console.WriteLine(para(arr)); 
            int para(params int[] a)
            {
                int ges = 0;
                int x = 0;
                while (x <=( a.Length-1))
                {
                    ges += a[x];
                    x++;
                }
                return ges / a.Length;
            }
        }
       
    }
}
