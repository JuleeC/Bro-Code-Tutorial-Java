﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp48
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 2;
            int y = 1;
            Swap.change(ref x, ref y);
            Console.WriteLine(x + " " + y);
            String c = "1";
            String d = "2";
            Swap.change_string(ref c, ref d);
            Console.WriteLine(c + " " + d);
        }
    }


    class Swap { 
    
        public static void change(ref int x, ref int y)
        {
            int a;
            a = x;
            x = y;
            y = a;
            
        }
        public static void change_string(ref String a,ref String b)
        {
            String c;
            c = b;
            b = a;
            a = c;
        }
    }
}
