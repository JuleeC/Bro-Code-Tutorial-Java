﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Primzahlen p = new Primzahlen();
            
            
                Console.WriteLine(p.Primfaktoren(40)[0]);
            Console.WriteLine(p.Primfaktoren(40)[1]);
            Console.WriteLine(p.Primfaktoren(40)[2]);
            Console.WriteLine(p.Primfaktoren(40)[3]);
            Console.WriteLine(p.Primfaktoren(40)[4]);

        }
    }
    class Primzahlen
    {
        int prim;

        public int[] Primfaktoren(int prim) {
            int counter=2;
            int k = 0;
            int[] arr = new int[100];
            while (prim != 1)
            {
                if(prim % counter == 0)
                {
                    prim /= counter;
                    
                    arr.Append(counter);
                    int i = 0;
                    
                    
                    arr[k] = counter;
                    k++;
                 //   Console.WriteLine(prim + " " + counter);
                    //}
                    counter = 2;
                }else
                {
                    counter++;
                }
            }
            return arr;

           
        }
    }
}
