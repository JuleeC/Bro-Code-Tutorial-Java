﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 1, 4, 3};
            Console.WriteLine(Quader.Volumen(arr));
        }
    }
    class Quader
    {
        public static int Volumen(int[] arr)
        {
            return arr[0] * arr[1] * arr[2];
        }
    }
}
