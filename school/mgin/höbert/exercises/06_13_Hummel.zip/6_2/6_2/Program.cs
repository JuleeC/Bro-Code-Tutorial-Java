﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace _6_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
           
            Console.WriteLine(new Rechteck().GetAllData()[0]);
            Console.WriteLine(new Rechteck().GetAllData()[1]);
            Console.WriteLine(new Rechteck().GetAllData()[2]);
            Console.WriteLine(new Rechteck().GetAllData()[3]);
            Console.WriteLine(new Rechteck().GetAllData()[4]);

        }
    }

    class Rechteck
    {
        int laenge = 4;
        int breite = 4;

        public int[] GetAllData()
        {
            int[] arr = {laenge,
                breite,
                (int)Math.Sqrt(laenge*laenge+breite*breite),
                laenge+laenge+breite+breite,
                laenge*breite};

            return arr;
           

        }
    }
}
