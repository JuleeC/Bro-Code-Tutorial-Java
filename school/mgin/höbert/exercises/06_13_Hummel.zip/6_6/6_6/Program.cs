﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrat.flaeche(3);
            Quadrat.flaeche(2.4);
        }
    }
    class Quadrat
    {
        public static int flaeche(int seitenlaenege)
        {
            return seitenlaenege * seitenlaenege;
        }   
        public static double flaeche(double seitenlaenge )
        {
            return seitenlaenge * seitenlaenge;
        }
    }
}
