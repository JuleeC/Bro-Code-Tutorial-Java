﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kreis k = new Kreis();
            Console.WriteLine(k.flaeche());
            Console.WriteLine(k.flaeche(5));
        }
    }
    class Kreis
    {
         double radius=5;

        public double flaeche()
        {
            return radius * radius * Math.PI;
        }
        public double flaeche(double radius) { 
            return radius *radius * Math.PI;
        }
    }
}
